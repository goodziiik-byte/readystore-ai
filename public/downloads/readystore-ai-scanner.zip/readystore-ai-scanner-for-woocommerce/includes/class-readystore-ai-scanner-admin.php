<?php
/**
 * Admin scanner screen.
 *
 * @package ReadystoreAIScanner
 */

if (!defined('ABSPATH')) {
    exit;
}

class Readystore_AI_Scanner_Admin {
    private static string $page_hook = '';

    public static function init(): void {
        add_action('admin_menu', [__CLASS__, 'register_menu']);
        add_action('admin_enqueue_scripts', [__CLASS__, 'enqueue_assets']);
    }

    public static function register_menu(): void {
        $capability = class_exists('WooCommerce') ? 'manage_woocommerce' : 'manage_options';

        self::$page_hook = add_menu_page(
            __('Readystore AI Scanner', 'readystore-ai-scanner-for-woocommerce'),
            __('Readystore AI', 'readystore-ai-scanner-for-woocommerce'),
            $capability,
            'readystore-ai-scanner-for-woocommerce',
            [__CLASS__, 'render_page'],
            'dashicons-search',
            56
        );
    }

    public static function enqueue_assets(string $hook): void {
        if ($hook !== self::$page_hook) {
            return;
        }

        wp_enqueue_style(
            'readystore-ai-scanner-admin',
            READYSTORE_AI_SCANNER_URL . 'assets/admin.css',
            [],
            READYSTORE_AI_SCANNER_VERSION
        );
    }

    public static function render_page(): void {
        if (!current_user_can(class_exists('WooCommerce') ? 'manage_woocommerce' : 'manage_options')) {
            wp_die(esc_html__('You do not have permission to view this page.', 'readystore-ai-scanner-for-woocommerce'));
        }

        $scan = self::run_local_scan();
        $score_class = self::score_class($scan['score']);
        $full_scan_url = self::full_scan_url();
        ?>
        <div class="wrap readystore-ai-wrap">
            <div class="readystore-ai-report-shell">
                <header class="readystore-ai-report-topbar">
                    <div class="readystore-ai-brand">
                        <span class="readystore-ai-logo" aria-hidden="true">⌗</span>
                        <span>Readystore<span> AI</span></span>
                    </div>
                    <a class="readystore-ai-button readystore-ai-button-secondary" href="<?php echo esc_url($full_scan_url); ?>" target="_blank" rel="noopener noreferrer">
                        <?php esc_html_e('Open public report', 'readystore-ai-scanner-for-woocommerce'); ?>
                    </a>
                </header>

                <section class="readystore-ai-report-hero">
                    <div>
                        <p class="readystore-ai-eyebrow"><?php esc_html_e('WooCommerce plugin scan', 'readystore-ai-scanner-for-woocommerce'); ?></p>
                        <h1><?php esc_html_e('Your store from inside WordPress.', 'readystore-ai-scanner-for-woocommerce'); ?></h1>
                        <p>
                            <?php esc_html_e('This local scan checks product data, store policies, AI discovery signals, checkout pages, and enabled payment gateways directly from WooCommerce.', 'readystore-ai-scanner-for-woocommerce'); ?>
                        </p>
                    </div>
                    <div class="readystore-ai-public-card">
                        <strong><?php esc_html_e('External buyer view', 'readystore-ai-scanner-for-woocommerce'); ?></strong>
                        <p><?php esc_html_e('The public report opens readystoreai.com and scans this store as an outside AI shopper would see it. No admin data is sent.', 'readystore-ai-scanner-for-woocommerce'); ?></p>
                        <a class="readystore-ai-button readystore-ai-button-primary" href="<?php echo esc_url($full_scan_url); ?>" target="_blank" rel="noopener noreferrer">
                            <?php esc_html_e('Run external scan', 'readystore-ai-scanner-for-woocommerce'); ?>
                        </a>
                    </div>
                </section>

                <section class="readystore-ai-score-card">
                    <div class="score-ring <?php echo esc_attr($score_class); ?>">
                        <span><?php echo esc_html(number_format_i18n($scan['score'], 1)); ?></span>
                        <small>/10</small>
                    </div>
                    <div>
                        <p class="readystore-ai-eyebrow"><?php esc_html_e('Local scan report', 'readystore-ai-scanner-for-woocommerce'); ?></p>
                        <h2><?php echo esc_html($scan['headline']); ?></h2>
                        <p><?php echo esc_html($scan['summary']); ?></p>
                    </div>
                </section>

                <div class="readystore-ai-grid">
                    <?php foreach ($scan['sections'] as $section) : ?>
                        <section class="readystore-ai-section is-<?php echo esc_attr($section['status']); ?>">
                            <div class="section-main">
                                <div class="section-heading-row">
                                    <div>
                                        <p class="section-label"><?php echo esc_html($section['label']); ?></p>
                                        <h3><?php echo esc_html($section['title']); ?></h3>
                                    </div>
                                    <span class="status-pill is-<?php echo esc_attr($section['status']); ?>">
                                        <?php echo esc_html(self::status_label($section['status'])); ?>
                                    </span>
                                </div>
                                <p><?php echo esc_html($section['description']); ?></p>
                                <?php if (!empty($section['items'])) : ?>
                                    <ul>
                                        <?php foreach ($section['items'] as $item) : ?>
                                            <li><?php echo esc_html($item); ?></li>
                                        <?php endforeach; ?>
                                    </ul>
                                <?php endif; ?>
                            </div>
                            <div class="section-status">
                                <span><?php esc_html_e('Score', 'readystore-ai-scanner-for-woocommerce'); ?></span>
                                <strong><?php echo esc_html($section['score']); ?>/10</strong>
                            </div>
                        </section>
                    <?php endforeach; ?>
                </div>

                <section class="readystore-ai-next">
                    <p class="readystore-ai-eyebrow"><?php esc_html_e('Recommended next layer', 'readystore-ai-scanner-for-woocommerce'); ?></p>
                    <h2><?php esc_html_e('Make the store easier for AI shoppers to understand and safer to hand off to checkout.', 'readystore-ai-scanner-for-woocommerce'); ?></h2>
                    <div class="readystore-ai-feature-grid">
                        <div>
                            <strong><?php esc_html_e('AI storefront layer', 'readystore-ai-scanner-for-woocommerce'); ?></strong>
                            <p><?php esc_html_e('Publish clean product, policy, payment, and freshness context in machine-readable formats.', 'readystore-ai-scanner-for-woocommerce'); ?></p>
                        </div>
                        <div>
                            <strong><?php esc_html_e('Safe checkout handoff', 'readystore-ai-scanner-for-woocommerce'); ?></strong>
                            <p><?php esc_html_e('Prepare a cart or payment link so the buyer can finish checkout safely on the merchant site.', 'readystore-ai-scanner-for-woocommerce'); ?></p>
                        </div>
                    </div>
                </section>
            </div>
        </div>
        <?php
    }

    private static function run_local_scan(): array {
        $woocommerce_active = class_exists('WooCommerce') && function_exists('wc_get_products');
        $product_sample = $woocommerce_active ? wc_get_products([
            'limit' => 25,
            'status' => 'publish',
            'return' => 'objects',
        ]) : [];

        $product_count = count($product_sample);
        $priced = 0;
        $stock = 0;
        $images = 0;
        $identifiers = 0;

        foreach ($product_sample as $product) {
            if ($product->get_price() !== '') {
                $priced++;
            }
            if ($product->get_stock_status()) {
                $stock++;
            }
            if ($product->get_image_id()) {
                $images++;
            }
            if ($product->get_sku()) {
                $identifiers++;
            }
        }

        $catalog_score = self::ratio_score($priced + $stock + $images + $identifiers, max(1, $product_count * 4));
        if (!$woocommerce_active || $product_count === 0) {
            $catalog_score = 0;
        }

        $checkout = self::checkout_status();
        $payments = self::payment_status();
        $policies = self::policy_status();
        $discovery = self::discovery_status();

        $sections = [
            [
                'label' => __('Product catalog', 'readystore-ai-scanner-for-woocommerce'),
                'title' => __('Can AI understand what you sell?', 'readystore-ai-scanner-for-woocommerce'),
                'description' => __('AI shoppers need stable product, price, stock, image, and identifier signals.', 'readystore-ai-scanner-for-woocommerce'),
                'status' => self::status_from_score($catalog_score),
                'score' => $catalog_score,
                'items' => [
                    sprintf(__('%d products sampled', 'readystore-ai-scanner-for-woocommerce'), $product_count),
                    sprintf(__('%d/%d have price data', 'readystore-ai-scanner-for-woocommerce'), $priced, $product_count),
                    sprintf(__('%d/%d have stock status', 'readystore-ai-scanner-for-woocommerce'), $stock, $product_count),
                    sprintf(__('%d/%d have product images', 'readystore-ai-scanner-for-woocommerce'), $images, $product_count),
                    sprintf(__('%d/%d have SKUs', 'readystore-ai-scanner-for-woocommerce'), $identifiers, $product_count),
                ],
            ],
            $policies,
            $discovery,
            $checkout,
            $payments,
        ];

        $score = round(array_sum(array_column($sections, 'score')) / max(1, count($sections)), 1);

        return [
            'score' => $score,
            'headline' => self::headline($score),
            'summary' => self::summary($woocommerce_active, $product_count, $payments),
            'sections' => $sections,
        ];
    }

    private static function checkout_status(): array {
        $cart_id = function_exists('wc_get_page_id') ? wc_get_page_id('cart') : 0;
        $checkout_id = function_exists('wc_get_page_id') ? wc_get_page_id('checkout') : 0;
        $cart_ok = $cart_id > 0 && get_post_status($cart_id) === 'publish';
        $checkout_ok = $checkout_id > 0 && get_post_status($checkout_id) === 'publish';

        $score = 0;
        if ($cart_ok) {
            $score += 3;
        }
        if ($checkout_ok) {
            $score += 4;
        }
        if ($cart_ok && $checkout_ok) {
            $score += 1;
        }

        return [
            'label' => __('Checkout path', 'readystore-ai-scanner-for-woocommerce'),
            'title' => __('Can AI identify the buying path?', 'readystore-ai-scanner-for-woocommerce'),
            'description' => __('A visible checkout path is not the same as an AI-ready checkout handoff, but it is the minimum requirement.', 'readystore-ai-scanner-for-woocommerce'),
            'status' => self::status_from_score($score),
            'score' => $score,
            'items' => [
                $cart_ok ? __('Cart page is published', 'readystore-ai-scanner-for-woocommerce') : __('Cart page is missing or unpublished', 'readystore-ai-scanner-for-woocommerce'),
                $checkout_ok ? __('Checkout page is published', 'readystore-ai-scanner-for-woocommerce') : __('Checkout page is missing or unpublished', 'readystore-ai-scanner-for-woocommerce'),
                __('AI checkout handoff still requires the full plugin layer', 'readystore-ai-scanner-for-woocommerce'),
            ],
        ];
    }

    private static function payment_status(): array {
        $enabled_gateways = [];

        if (function_exists('WC') && WC() && WC()->payment_gateways()) {
            foreach (WC()->payment_gateways()->payment_gateways() as $gateway) {
                if (isset($gateway->enabled) && $gateway->enabled === 'yes') {
                    $enabled_gateways[] = $gateway->get_title() ?: $gateway->id;
                }
            }
        }

        $score = count($enabled_gateways) > 0 ? 6 : 2;

        return [
            'label' => __('Payment context', 'readystore-ai-scanner-for-woocommerce'),
            'title' => __('Can AI see how buyers can pay?', 'readystore-ai-scanner-for-woocommerce'),
            'description' => __('Enabled gateways help, but AI shoppers still need a clean payment and checkout context layer.', 'readystore-ai-scanner-for-woocommerce'),
            'status' => self::status_from_score($score),
            'score' => $score,
            'items' => count($enabled_gateways) > 0
                ? array_merge(
                    [sprintf(__('%d enabled payment gateway(s)', 'readystore-ai-scanner-for-woocommerce'), count($enabled_gateways))],
                    array_slice($enabled_gateways, 0, 5)
                )
                : [__('No enabled WooCommerce payment gateways detected', 'readystore-ai-scanner-for-woocommerce')],
        ];
    }

    private static function policy_status(): array {
        $shipping = self::find_page_by_slug_keywords(['shipping', 'delivery', 'pengiriman', 'envio', 'entrega']);
        $returns = self::find_page_by_slug_keywords(['return', 'refund', 'returns', 'devolucion', 'troca', 'retur']);
        $terms_id = (int) get_option('woocommerce_terms_page_id', 0);
        $privacy_id = (int) get_option('wp_page_for_privacy_policy', 0);

        $score = 0;
        if ($shipping) {
            $score += 3;
        }
        if ($returns) {
            $score += 3;
        }
        if ($terms_id > 0) {
            $score += 2;
        }
        if ($privacy_id > 0) {
            $score += 1;
        }

        return [
            'label' => __('Trust and policies', 'readystore-ai-scanner-for-woocommerce'),
            'title' => __('Can AI confirm store trust signals?', 'readystore-ai-scanner-for-woocommerce'),
            'description' => __('Shipping, returns, terms, and privacy pages help AI assistants recommend a store with confidence.', 'readystore-ai-scanner-for-woocommerce'),
            'status' => self::status_from_score($score),
            'score' => $score,
            'items' => [
                $shipping ? __('Shipping or delivery page found', 'readystore-ai-scanner-for-woocommerce') : __('Shipping or delivery page not found', 'readystore-ai-scanner-for-woocommerce'),
                $returns ? __('Return or refund page found', 'readystore-ai-scanner-for-woocommerce') : __('Return or refund page not found', 'readystore-ai-scanner-for-woocommerce'),
                $terms_id > 0 ? __('WooCommerce terms page configured', 'readystore-ai-scanner-for-woocommerce') : __('WooCommerce terms page not configured', 'readystore-ai-scanner-for-woocommerce'),
                $privacy_id > 0 ? __('Privacy policy page configured', 'readystore-ai-scanner-for-woocommerce') : __('Privacy policy page not configured', 'readystore-ai-scanner-for-woocommerce'),
            ],
        ];
    }

    private static function discovery_status(): array {
        $sitemap = home_url('/wp-sitemap.xml');
        $llms = wp_remote_head(home_url('/llms.txt'), ['timeout' => 3]);
        $llms_ok = !is_wp_error($llms) && (int) wp_remote_retrieve_response_code($llms) >= 200 && (int) wp_remote_retrieve_response_code($llms) < 400;

        $score = 4;
        if ($llms_ok) {
            $score += 4;
        }

        return [
            'label' => __('AI discovery', 'readystore-ai-scanner-for-woocommerce'),
            'title' => __('Can AI find machine-readable context?', 'readystore-ai-scanner-for-woocommerce'),
            'description' => __('AI-readable manifests and feeds make product, policy, payment, and checkout context easier to discover.', 'readystore-ai-scanner-for-woocommerce'),
            'status' => self::status_from_score($score),
            'score' => $score,
            'items' => [
                sprintf(__('WordPress sitemap: %s', 'readystore-ai-scanner-for-woocommerce'), $sitemap),
                $llms_ok ? __('llms.txt found', 'readystore-ai-scanner-for-woocommerce') : __('llms.txt not found', 'readystore-ai-scanner-for-woocommerce'),
            ],
        ];
    }

    private static function full_scan_url(): string {
        $domain = wp_parse_url(home_url(), PHP_URL_HOST) ?: home_url();

        return add_query_arg(
            [
                'domain' => $domain,
                'utm_source' => 'wordpress_plugin',
                'utm_medium' => 'plugin_admin',
                'utm_campaign' => 'wp_plugin_lite',
            ],
            'https://readystoreai.com/en'
        );
    }

    private static function find_page_by_slug_keywords(array $keywords): bool {
        foreach ($keywords as $keyword) {
            $pages = get_posts([
                'post_type' => 'page',
                'post_status' => 'publish',
                's' => $keyword,
                'numberposts' => 1,
            ]);

            if (!empty($pages)) {
                return true;
            }
        }

        return false;
    }

    private static function ratio_score(int $value, int $max): int {
        return (int) min(10, max(0, round(($value / max(1, $max)) * 10)));
    }

    private static function status_from_score(int $score): string {
        if ($score >= 8) {
            return 'good';
        }
        if ($score >= 6) {
            return 'partial';
        }

        return 'missing';
    }

    private static function score_class(float $score): string {
        if ($score >= 8) {
            return 'good';
        }
        if ($score >= 6) {
            return 'partial';
        }

        return 'missing';
    }

    private static function status_label(string $status): string {
        if ($status === 'good') {
            return __('Good', 'readystore-ai-scanner-for-woocommerce');
        }
        if ($status === 'partial') {
            return __('Partial', 'readystore-ai-scanner-for-woocommerce');
        }

        return __('Needs work', 'readystore-ai-scanner-for-woocommerce');
    }

    private static function headline(float $score): string {
        if ($score >= 8) {
            return __('Mostly ready, but not AI-buyable yet', 'readystore-ai-scanner-for-woocommerce');
        }
        if ($score >= 6) {
            return __('Partly ready for AI shoppers', 'readystore-ai-scanner-for-woocommerce');
        }

        return __('Important AI shopping signals are missing', 'readystore-ai-scanner-for-woocommerce');
    }

    private static function summary(bool $woocommerce_active, int $product_count, array $payments): string {
        if (!$woocommerce_active) {
            return __('WooCommerce was not detected as active. Install and activate WooCommerce before running a store readiness scan.', 'readystore-ai-scanner-for-woocommerce');
        }

        return sprintf(
            __('The plugin inspected %1$d public products, policy settings, checkout pages, and payment gateway signals. Payment context: %2$s.', 'readystore-ai-scanner-for-woocommerce'),
            $product_count,
            $payments['score'] >= 6 ? __('gateway detected, AI handoff still missing', 'readystore-ai-scanner-for-woocommerce') : __('unclear or missing', 'readystore-ai-scanner-for-woocommerce')
        );
    }
}
