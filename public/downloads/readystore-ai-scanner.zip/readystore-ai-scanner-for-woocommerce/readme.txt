=== Readystore AI Scanner for WooCommerce ===
Contributors: goodz1k
Tags: woocommerce, ai, ecommerce, structured-data, llms.txt
Requires at least: 6.3
Tested up to: 7.0
Requires PHP: 7.4
Stable tag: 0.1.0
Requires Plugins: woocommerce
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Scan your WooCommerce store for AI shopping readiness: products, prices, stock, policies, checkout, payment signals, and llms.txt.

== Description ==

Readystore AI Scanner helps WooCommerce merchants understand whether AI shopping assistants can read, trust, and recommend their store.

AI shoppers do not ask for schema, policy links, or checkout metadata. They ask simple buying questions:

* Can I trust this store?
* Is this product available?
* How much does it cost?
* Does it ship to me?
* Can I pay safely?

This plugin gives merchants a quick in-admin readiness check for:

* WooCommerce status
* Product catalog signals
* Price and stock coverage
* Product images and identifiers
* Shipping, return, privacy, and terms policy hints
* Cart and checkout page presence
* Enabled WooCommerce payment gateways
* llms.txt availability

The plugin also links to the public Readystore AI scanner for an outside-in report.

= Privacy and safety =

The scanner checks store configuration and public storefront context only.

It does not:

* create orders
* submit checkout forms
* access payment data
* store customer data
* send product data to Readystore AI automatically
* require admin access to Readystore AI

== Installation ==

1. Upload the plugin ZIP through `Plugins -> Add New -> Upload Plugin`.
2. Activate the plugin.
3. Open `WooCommerce -> AI Readiness`.
4. Review the local scan and open the public report if needed.

== Frequently Asked Questions ==

= Does this replace SEO plugins? =

No. Readystore AI focuses on AI shopping readiness for WooCommerce: product clarity, policy context, checkout visibility, payment context, and AI-readable discovery signals.

= Does this plugin process payments? =

No. This scanner version does not process payments, create orders, or submit checkout forms.

= Does it work with local payment providers? =

The scanner detects enabled WooCommerce payment gateways in the store admin. It does not create payment links or submit checkout.

= What is llms.txt? =

llms.txt is an emerging convention for giving AI systems a simple discovery file. This scanner checks whether it exists.

== Changelog ==

= 0.1.0 =

* First lightweight scanner release.
* Added WooCommerce, catalog, policy, checkout, payment, and llms.txt checks.
