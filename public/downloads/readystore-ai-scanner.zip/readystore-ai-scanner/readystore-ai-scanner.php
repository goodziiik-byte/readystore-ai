<?php
/**
 * Plugin Name: Readystore AI Scanner for WooCommerce
 * Plugin URI: https://readystoreai.com/wordpress-plugin/
 * Description: Scan WooCommerce stores for AI shopping readiness: products, prices, stock, policies, checkout, payment signals, and llms.txt.
 * Version: 0.1.0
 * Author: Readystore AI
 * Author URI: https://readystoreai.com/
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Requires at least: 6.3
 * Requires PHP: 7.4
 * Text Domain: readystore-ai-scanner
 * Requires Plugins: woocommerce
 *
 * @package ReadystoreAIScanner
 */

if (!defined('ABSPATH')) {
    exit;
}

define('READYSTORE_AI_SCANNER_VERSION', '0.1.0');
define('READYSTORE_AI_SCANNER_FILE', __FILE__);
define('READYSTORE_AI_SCANNER_DIR', plugin_dir_path(__FILE__));
define('READYSTORE_AI_SCANNER_URL', plugin_dir_url(__FILE__));

require_once READYSTORE_AI_SCANNER_DIR . 'includes/class-readystore-ai-scanner-admin.php';

add_action('plugins_loaded', static function (): void {
    Readystore_AI_Scanner_Admin::init();
});
